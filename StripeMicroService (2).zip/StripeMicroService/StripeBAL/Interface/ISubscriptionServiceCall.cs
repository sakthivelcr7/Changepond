﻿using StripeDAL.Models;

namespace StripeBAL.Interface
{
    public interface ISubscriptionServiceCall
    {

        bool CreateCustomer(CustomerRequest request, out string customerId);
        bool CreateProduct(ProductRequest request, out string productId, out string priceId);
        bool CreateSubscription(SubscriptionRequest request, out string subscriptionId);

    }
}

