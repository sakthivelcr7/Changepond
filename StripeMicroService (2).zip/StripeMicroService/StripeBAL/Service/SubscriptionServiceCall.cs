﻿using StripeBAL.Interface;
using StripeDAL.Repository;
using StripeDAL.Models;

namespace StripeBAL.Service
{
    public class SubscriptionServiceCall : ISubscriptionServiceCall
    {
        private readonly ISubscriptionService _subscriptionService;

        public SubscriptionServiceCall(ISubscriptionService subscriptionService)
        {
            _subscriptionService = subscriptionService;
        }

        public bool CreateCustomer(CustomerRequest request, out string customerId)
        {
            // Call the DAL method
            return _subscriptionService.CreateCustomer(request, out customerId);
        }

        public bool CreateProduct(ProductRequest request, out string productId, out string priceId)
        {
            // Call the DAL method
            return _subscriptionService.CreateProduct(request, out productId, out priceId);
        }

        public bool CreateSubscription(SubscriptionRequest request, out string subscriptionId)
        {
            // Call the DAL method
            return _subscriptionService.CreateSubscription(request, out subscriptionId);
        }
    }
}

