﻿using Microsoft.AspNetCore.Mvc;
using StripeBAL.Interface;
using StripeBAL.Service;
using StripeDAL.Models;

namespace StripeMicroService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubscriptionController : ControllerBase
    {
        private readonly ISubscriptionServiceCall _subscriptionServiceCall;

        public SubscriptionController(ISubscriptionServiceCall subscriptionServiceCall)
        {
            _subscriptionServiceCall = subscriptionServiceCall;
        }

        [HttpPost("create-customer")]
        public IActionResult CreateCustomer(CustomerRequest request)
        {
            if (_subscriptionServiceCall.CreateCustomer(request, out string customerId))
            {
                return Ok(new { CustomerId = customerId });
            }
            return BadRequest("Failed to create customer");
        }

        [HttpPost("create-product")]
        public IActionResult CreateProduct(ProductRequest request)
        {
            if (_subscriptionServiceCall.CreateProduct(request, out string productId, out string priceId))
            {
                return Ok(new { ProductId = productId, PriceId = priceId });
            }
            return BadRequest("Failed to create product");
        }

        [HttpPost("create-subscription")]
        public IActionResult CreateSubscription(SubscriptionRequest request)
        {
            if (_subscriptionServiceCall.CreateSubscription(request, out string subscriptionId))
            {
                return Ok(new { SubscriptionId = subscriptionId });
            }
            return BadRequest("Failed to create subscription");
        }
    }
}
