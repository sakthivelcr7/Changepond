﻿using NUnit.Framework;
using Moq;
using StripeBAL.Interface;
using StripeDAL.Models;
using StripeMicroService.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace UnitTest.Controllers
{
    [TestFixture]
    public class SubscriptionControllerTests
    {
        private SubscriptionController _controller;
        private Mock<ISubscriptionServiceCall> _subscriptionServiceMock;

        [SetUp]
        public void SetUp()
        {
            _subscriptionServiceMock = new Mock<ISubscriptionServiceCall>();
            _controller = new SubscriptionController(_subscriptionServiceMock.Object);
        }

        // -------------------------- Positive Tests --------------------------

        [Test]
        public void CreateCustomer_ValidRequest_ReturnsOk()
        {
            // Arrange
            _subscriptionServiceMock.Setup(service => service.CreateCustomer(It.IsAny<CustomerRequest>(), out It.Ref<string>.IsAny))
                .Returns(true)
                .Callback<CustomerRequest, string>((request, customerId) => customerId = "cust_123");

            var customerRequest = new CustomerRequest { Name = "Test Customer", Email = "test@example.com" };

            // Act
            var result = _controller.CreateCustomer(customerRequest) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual("cust_123", result.Value);
        }

        [Test]
        public void CreateProduct_ValidRequest_ReturnsOk()
        {
            // Arrange
            _subscriptionServiceMock.Setup(service => service.CreateProduct(It.IsAny<ProductRequest>(), out It.Ref<string>.IsAny, out It.Ref<string>.IsAny))
                .Returns(true)
                .Callback<ProductRequest, string, string>((request, productId, priceId) =>
                {
                    productId = "prod_123";
                    priceId = "price_123";
                });

            var productRequest = new ProductRequest { Name = "Test Product", Description = "Test Description" };

            // Act
            var result = _controller.CreateProduct(productRequest) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
        }

        [Test]
        public void CreateSubscription_ValidRequest_ReturnsOk()
        {
            // Arrange
            _subscriptionServiceMock.Setup(service => service.CreateSubscription(It.IsAny<SubscriptionRequest>(), out It.Ref<string>.IsAny))
                .Returns(true)
                .Callback<SubscriptionRequest, string>((request, subscriptionId) => subscriptionId = "sub_123");

            var subscriptionRequest = new SubscriptionRequest { CustomerId = "cust_123", PriceId = "prod_123" };

            // Act
            var result = _controller.CreateSubscription(subscriptionRequest) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual("sub_123", result.Value);
        }

        // -------------------------- Negative Tests --------------------------

        [Test]
        public void CreateCustomer_InvalidRequest_ReturnsBadRequest()
        {
            // Arrange
            _subscriptionServiceMock.Setup(service => service.CreateCustomer(It.IsAny<CustomerRequest>(), out It.Ref<string>.IsAny))
                .Returns(false); // Simulate failure

            var customerRequest = new CustomerRequest { Name = "", Email = "invalid" };

            // Act
            var result = _controller.CreateCustomer(customerRequest) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(400, result.StatusCode);
        }

        [Test]
        public void CreateProduct_InvalidRequest_ReturnsBadRequest()
        {
            // Arrange
            _subscriptionServiceMock.Setup(service => service.CreateProduct(It.IsAny<ProductRequest>(), out It.Ref<string>.IsAny, out It.Ref<string>.IsAny))
                .Returns(false); // Simulate failure

            var productRequest = new ProductRequest { Name = "", Description = "Test Description" };

            // Act
            var result = _controller.CreateProduct(productRequest) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(400, result.StatusCode);
        }

        [Test]
        public void CreateSubscription_InvalidRequest_ReturnsBadRequest()
        {
            // Arrange
            _subscriptionServiceMock.Setup(service => service.CreateSubscription(It.IsAny<SubscriptionRequest>(), out It.Ref<string>.IsAny))
                .Returns(false); // Simulate failure

            var subscriptionRequest = new SubscriptionRequest { CustomerId = "", PriceId = "prod_123" };

            // Act
            var result = _controller.CreateSubscription(subscriptionRequest) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(400, result.StatusCode);
        }
    }
}
