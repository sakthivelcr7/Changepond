﻿using Moq;
using StripeBAL.Interface;

using StripeDAL.Models;
using System.Collections.Generic;

namespace UnitTest.Mock
{
    public class SubscriptionDALMock : Mock<ISubscriptionServiceCall>
    {
        public SubscriptionDALMock() : base(MockBehavior.Strict) { }

        public void SetupCreateCustomer()
        {
            Setup(dal => dal.CreateCustomer(It.IsAny<CustomerRequest>(), out It.Ref<string>.IsAny))
                .Returns(true)
                .Callback<CustomerRequest, string>((request, customerId) => customerId = "cust_123");
        }

        public void SetupCreateProduct()
        {
            Setup(dal => dal.CreateProduct(It.IsAny<ProductRequest>(), out It.Ref<string>.IsAny, out It.Ref<string>.IsAny))
                .Returns(true)
                .Callback<ProductRequest, string, string>((request, productId, priceId) =>
                {
                    productId = "prod_123";
                    priceId = "price_123";
                });
        }

        public void SetupCreateSubscription()
        {
            Setup(dal => dal.CreateSubscription(It.IsAny<SubscriptionRequest>(), out It.Ref<string>.IsAny))
                .Returns(true)
                .Callback<SubscriptionRequest, string>((request, subscriptionId) => subscriptionId = "sub_123");
        }
    }
}
