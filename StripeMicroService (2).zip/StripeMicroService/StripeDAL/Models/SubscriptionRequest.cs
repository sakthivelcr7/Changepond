﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeDAL.Models
{
    public class SubscriptionRequest
    {
        public string CustomerId { get; set; }
        public string PriceId { get; set; }
    }
}
