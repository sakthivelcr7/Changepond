﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeDAL.Models
{
    public class CustomerRequest
    {
        public string Email { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
