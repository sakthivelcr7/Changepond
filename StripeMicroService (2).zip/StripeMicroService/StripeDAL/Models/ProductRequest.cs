﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeDAL.Models
{
    public class ProductRequest
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public long Price { get; set; } // In the smallest unit (e.g., cents)
        public bool IsRecurring { get; set; } // Whether it's recurring or one-off
        public string Interval { get; set; } // month, year, etc., only if recurring
    }
}
