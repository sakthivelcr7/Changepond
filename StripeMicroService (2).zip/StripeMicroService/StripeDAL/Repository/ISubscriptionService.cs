﻿using StripeDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeDAL.Repository
{
    public interface ISubscriptionService
    {
        bool CreateCustomer(CustomerRequest request, out string customerId);
        bool CreateProduct(ProductRequest request, out string productId, out string priceId);
        bool CreateSubscription(SubscriptionRequest request, out string subscriptionId);
    }
}
