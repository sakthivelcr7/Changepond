﻿using Stripe;
using StripeDAL.Models;
//using StripeMicroService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeDAL.Repository
{
   

        public class SubscriptionService1 : ISubscriptionService
        {
            public bool CreateCustomer(CustomerRequest request, out string customerId)
            {
                try
                {
                    var customerOptions = new CustomerCreateOptions
                    {
                        Email = request.Email,
                        Name = request.Name,
                        Description = request.Description
                    };

                    var customerService = new CustomerService();
                    var customer = customerService.Create(customerOptions);

                    customerId = customer.Id;
                    return true;
                }
                catch (StripeException)
                {
                    customerId = null;
                    return false;
                }
            }

            public bool CreateProduct(ProductRequest request, out string productId, out string priceId)
            {
                try
                {
                    var productOptions = new ProductCreateOptions
                    {
                        Name = request.Name,
                        Description = request.Description,
                    };

                    var productService = new ProductService();
                    var product = productService.Create(productOptions);

                    var priceOptions = new PriceCreateOptions
                    {
                        UnitAmount = request.Price,
                        Currency = "usd",
                        Product = product.Id,
                    };

                    if (request.IsRecurring)
                    {
                        priceOptions.Recurring = new PriceRecurringOptions
                        {
                            Interval = request.Interval,
                        };
                    }

                    var priceService = new PriceService();
                    var price = priceService.Create(priceOptions);

                    productId = product.Id;
                    priceId = price.Id;
                    return true;
                }
                catch (StripeException)
                {
                    productId = null;
                    priceId = null;
                    return false;
                }
            }

        public bool CreateSubscription(SubscriptionRequest request, out string subscriptionId)
        {
            try
            {
                var options = new SubscriptionCreateOptions
                {
                    Customer = request.CustomerId,
                    Items = new List<SubscriptionItemOptions>
            {
                new SubscriptionItemOptions { Price = request.PriceId }
            },
                };

                var stripeSubscriptionService = new Stripe.SubscriptionService();
                var subscription = stripeSubscriptionService.Create(options);

                subscriptionId = subscription.Id;
                return true;
            }
            catch (StripeException)
            {
                subscriptionId = null;
                return false;
            }
        }

    }

}
