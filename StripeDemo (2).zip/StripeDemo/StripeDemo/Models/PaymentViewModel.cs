﻿namespace StripeDemo.Models
{
    public class PaymentViewModel
    {
        //public string PaymentMethodId { get; set; }
        public string PaymentMethodId { get; set; }
        public double Amount { get; set; } // Amount in dollars
        public string Currency { get; set; } // e.g., "usd"
        public string CustomerName { get; set; }
        public string CustomerEmail { get; set; }
    }
}
