﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Stripe;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace StripeDemo.Models
{
    public class RecurringPaymentViewModel
    {
        [Required]
        public string CustomerName { get; set; }

        [Required]
        [EmailAddress]
        public string CustomerEmail { get; set; }

        [Required]
        public string ProductId { get; set; }

        public List<SelectListItem> AvailableProducts { get; set; }

        public string CardNumber { get; set; }
        public long ExpiryMonth { get; set; }
        public long ExpiryYear { get; set; }
        public string CVC { get; set; }
        //[Required]
        //public string CustomerName { get; set; }

        //[Required]
        //[EmailAddress]
        //public string CustomerEmail { get; set; }

        //[Required]
        //public string ProductId { get; set; }

        //public List<Product> AvailableProducts { get; set; }

        //[Required]
        //public string CardNumber { get; set; }

        //[Required]
        //public string ExpiryMonth { get; set; }

        //[Required]
        //public string ExpiryYear { get; set; }

        //[Required]
        //public string CVC { get; set; }
        //[Required]
        //[Display(Name = "Card Number")]
        //public string CardNumber { get; set; }

        //[Required]
        //[Display(Name = "Expiry Month")]
        //public string ExpiryMonth { get; set; }

        //[Required]
        //[Display(Name = "Expiry Year")]
        //public string ExpiryYear { get; set; }

        //[Required]
        //[Display(Name = "CVC")]
        //public string CVC { get; set; }

        //[Required]
        //[Range(1, double.MaxValue, ErrorMessage = "Amount must be greater than 0.")]
        //[Display(Name = "Amount")]
        //public decimal Amount { get; set; }

        //[Required]
        //[Range(1, 12, ErrorMessage = "Frequency must be between 1 and 12 months.")]
        //[Display(Name = "Frequency (Months)")]
        //public int Frequency { get; set; }

        //[Required]
        //[EmailAddress]
        //[Display(Name = "Customer Email")]
        //public string CustomerEmail { get; set; }

        //[Required]
        //[Display(Name = "Currency")]
        //public string SelectedCurrency { get; set; }

        //public List<string> SupportedCurrencies { get; set; } = new List<string> { "USD", "EUR", "GBP", "INR" };
    }
}
