﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Stripe;
using Stripe.Checkout;
using StripeDemo.Models;
using System.Collections.Generic;
namespace StripeDemo.Controllers
{
   

  
    public class SubscriptionController : Controller
    {

        private readonly StripeSettings _stripeSettings;

        public SubscriptionController(IOptions<StripeSettings> stripeSettings)
        {
            _stripeSettings = stripeSettings.Value;
        }
        //public IActionResult Index()
        //{
        //    return View();
        //}

        public IActionResult Index()
        {
            ViewBag.PublishableKey = _stripeSettings.PublishableKey; // Pass the publishable key to the view
            return View();
        }

        [HttpPost]
        public IActionResult CreateCheckoutSession()
        {
            var options = new SessionCreateOptions
            {
                PaymentMethodTypes = new List<string> { "card" },
                Mode = "subscription",
                LineItems = new List<SessionLineItemOptions>
                {
                    new SessionLineItemOptions
                    {
                        Price = "price_1Q13a801eYaFfzVBBP6XHAfz", // Replace with actual Price ID from Stripe
                        Quantity = 1,
                    },
                },
                SuccessUrl = Url.Action("Success", "Subscription", new { session_id = "{CHECKOUT_SESSION_ID}" }, protocol: Request.Scheme),
                CancelUrl = Url.Action("Cancel", "Subscription", null, protocol: Request.Scheme),
            };

            var service = new SessionService();
            Session session = service.Create(options);

            return Json(new { id = session.Id });
        }
    

    //[HttpPost]
    //public IActionResult CreateCheckoutSession()
    //{
    //    StripeConfiguration.ApiKey = "sk_test_51PzZWX01eYaFfzVBg4r3xfdlIezLHwm7Oyk3isI0rjbAWQE7XzQZFs6zJvT1TJi8Bp8SGZ1oGA61vzdfI5OMZANc00GssYUSvc"; // Your secret key from Stripe Dashboard

    //    var options = new SessionCreateOptions
    //    {
    //        PaymentMethodTypes = new List<string> { "card" },
    //        Mode = "subscription", // Set mode to subscription for recurring payments
    //        LineItems = new List<SessionLineItemOptions>
    //    {
    //        new SessionLineItemOptions
    //        {
    //            Price = "price_1Q2VPq01eYaFfzVBHsZlqi8Q", // Replace with your actual Price ID
    //            Quantity = 1,
    //        },
    //    },
    //        SuccessUrl = Url.Action("Success", "Subscription", new { session_id = "{CHECKOUT_SESSION_ID}" }, protocol: Request.Scheme),
    //        CancelUrl = Url.Action("Cancel", "Subscription", null, protocol: Request.Scheme),
    //    };

    //    var service = new SessionService();
    //    Session session = service.Create(options);

    //    return Json(new { id = session.Id }); // Returns the session ID for frontend use
    //}

    public IActionResult Success(string session_id)
        {
            // This action is called after successful payment
            ViewBag.SessionId = session_id;
            return View();
        }

        public IActionResult Cancel()
        {
            // This action is called if the payment is cancelled
            return View();
        }
    }
    

}
