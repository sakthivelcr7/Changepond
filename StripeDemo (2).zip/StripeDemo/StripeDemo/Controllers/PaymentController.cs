﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Options;
using Stripe;
using StripeDemo.Models;
using Product = StripeDemo.Models.Product;namespace StripeDemo.Controllers{

    [Route("Payment")]    [ApiController]    public class PaymentController : Controller    {
        private readonly StripeSettings _stripeSettings;

        public PaymentController(IOptions<StripeSettings> stripeSettings)
        {
            _stripeSettings = stripeSettings.Value;
        }
        public IActionResult Index()        {            return View();        }




        [HttpPost("createpaymentintent")]        public async Task<IActionResult> CreatePaymentIntent([FromBody] PaymentViewModel request)        {            try            {                var customerService = new CustomerService();                var paymentMethodService = new PaymentMethodService();

                // 1. Create or retrieve the customer
                var customerOptions = new CustomerCreateOptions                {                    Name = request.CustomerName,                    Email = request.CustomerEmail,                    Description = "Created during payment process"                };                var customer = await customerService.CreateAsync(customerOptions);

                // 2. Attach the payment method to the customer
                var attachOptions = new PaymentMethodAttachOptions                {                    Customer = customer.Id                };                await paymentMethodService.AttachAsync(request.PaymentMethodId, attachOptions);

                // 3. Set the default payment method for the customer
                var updateOptions = new CustomerUpdateOptions                {                    InvoiceSettings = new CustomerInvoiceSettingsOptions                    {                        DefaultPaymentMethod = request.PaymentMethodId                    }                };                await customerService.UpdateAsync(customer.Id, updateOptions);

                // 4. Create a payment intent with the new customer
                var intentOptions = new PaymentIntentCreateOptions                {                    Amount = (long)(request.Amount * 100), // Convert amount to cents
                    Currency = request.Currency,                    PaymentMethod = request.PaymentMethodId,                    Customer = customer.Id,                    ConfirmationMethod = "manual",                    Confirm = true,                };                var intentService = new PaymentIntentService();                var intent = await intentService.CreateAsync(intentOptions);

                return Ok(new                {                    success = true,                    clientSecret = intent.ClientSecret                });            }            catch (StripeException e)            {                return BadRequest(new                {                    success = false,                    error = e.Message                });            }        }

      


    
        

    }}